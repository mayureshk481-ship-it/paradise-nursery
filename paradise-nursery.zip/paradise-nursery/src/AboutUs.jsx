import React from 'react';

function AboutUs() {
  return (
    <div className="about-us">
      <h2>About Paradise Nursery</h2>
      <p>
        Paradise Nursery is a family-run plant shop dedicated to bringing the calm of the
        outdoors into your home. We grow and select every houseplant by hand, so each one
        arrives healthy, vibrant and ready to thrive.
      </p>
      <p>
        Our collection covers air-purifying plants that freshen your rooms, aromatic herbs
        that make your space smell wonderful, and low-maintenance succulents for busy
        plant lovers. Whether you are buying your first plant or adding to a growing
        jungle, our team is here with friendly care tips and honest advice.
      </p>
      <p>
        We believe green spaces make people happier, healthier and more creative. Browse
        our plants, pick your favourites and let us help you create your own little
        paradise.
      </p>
    </div>
  );
}

export default AboutUs;
